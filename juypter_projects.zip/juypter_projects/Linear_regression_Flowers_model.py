#!/usr/bin/env python
# coding: utf-8

# In[5]:


import sklearn
import pandas 
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
iris = pandas.read_csv('iris.csv')


# In[6]:


names = ['seplal-length', 'sepal-width', 'petal-length', 'petal-width']


# In[7]:


IRIS = iris.data
print(IRIS.shape)
print(iris.feature_names)
x=iris.data
y=iris.target
import sklearn.model_selection


# In[68]:


df = pandas.DataFrame(IRIS, columns=['seplal-width', 'sepal-length', 'petal-length', 'petal-width'])


# In[69]:


print(df)


# In[70]:


print(df.describe())


# In[ ]:





# In[71]:


df.plot(kind = 'box')


# In[72]:


df.hist()


# In[73]:


scatter_matrix(df)


# In[74]:


pd.plotting.scatter_matrix(df)


# In[76]:


validation_size  = 0.2
seed = 6 
x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(x, y, random_state=seed,  test_size = validation_size)


# In[78]:


print(x_trai


# In[81]:


print(int(x_test.size)/4)


# In[ ]:




